## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(imputeTestbench)

## ----load---------------------------------------------------------------------
library(imputeTestbench)
data("EuStockMarkets")
# Preview the data
head(EuStockMarkets)

## ----run----------------------------------------------------------------------
mv_results <- mv_impute_errors(
  multi_dataIn = EuStockMarkets,
  missPercentFrom = 10,
  missPercentTo = 30,
  interval = 10,
  repetition = 3   # low for vignette speed
)

## ----explore------------------------------------------------------------------
# Names of the list (the stock indices)
names(mv_results)

# Results for the DAX index
mv_results$DAX

# Average RMSE for the 'na.approx' method on DAX
mv_results$DAX$na.approx

# Access the raw errors (all repetitions) for SMI
str(attr(mv_results$SMI, "errall"), max.level = 2)

## ----compare------------------------------------------------------------------
compare_df <- do.call(rbind, lapply(names(mv_results), function(var) {
  res_var <- mv_results[[var]]
  data.frame(
    variable = var,
    missPercent = res_var$MissingPercent,
    approx = res_var$na.approx,
    interp = res_var$na.interp,
    locf = res_var$na.locf,
    mean = res_var$na_mean
  )
}))
head(compare_df)

